"""Deterministic CRM business rules."""
