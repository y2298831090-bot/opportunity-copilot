"""Application orchestration boundaries."""
